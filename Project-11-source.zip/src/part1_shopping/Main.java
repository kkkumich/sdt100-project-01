package part1_shopping;
public class Main {public static void main(String[] args){ShoppingListManager list=new ShoppingListManager();list.addItem("Milk");list.addItem("Bread");list.displayItems();list.removeItem("Milk");System.out.println("After removing Milk:");list.displayItems();}}
