package part1_shopping;
import java.util.ArrayList;
public class ShoppingListManager {
    private final ArrayList<String> items=new ArrayList<>();
    public void addItem(String item){if(item==null||item.trim().isEmpty())throw new IllegalArgumentException("Blank item");items.add(item);}
    public boolean removeItem(String item){return items.remove(item);}
    public void displayItems(){for(int i=0;i<items.size();i++)System.out.println(i+": "+items.get(i));}
    public int size(){return items.size();}
}
