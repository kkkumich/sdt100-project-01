package part3_grades;
import java.util.ArrayList;
public class StudentGrades {
    private final ArrayList<Double> grades=new ArrayList<>();
    public void addGrade(double grade){if(!Double.isFinite(grade)||grade<0||grade>100)throw new IllegalArgumentException("Grade must be 0-100");grades.add(grade);}
    public ArrayList<Double> getGradesAbove(double threshold){ArrayList<Double> result=new ArrayList<>();for(double g:grades)if(g>threshold)result.add(g);return result;}
    public double getAverageGrade(){if(grades.isEmpty())throw new IllegalStateException("No grades");double sum=0;for(double g:grades)sum+=g;return sum/grades.size();}
    public void removeLowestGrade(){if(grades.isEmpty())throw new IllegalStateException("No grades");int index=0;for(int i=1;i<grades.size();i++)if(grades.get(i)<grades.get(index))index=i;grades.remove(index);}
    public String toString(){return grades.toString();}
}
