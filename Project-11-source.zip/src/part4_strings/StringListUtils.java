package part4_strings;
import java.util.ArrayList;
public class StringListUtils {
    private final ArrayList<String> sentences=new ArrayList<>();
    public void addSentence(String s){if(s==null)throw new IllegalArgumentException("Null sentence");sentences.add(s);}
    private String[] words(String s){return s.trim().isEmpty()?new String[0]:s.trim().split("\\s+");}
    public int countWords(){int total=0;for(String s:sentences)total+=words(s).length;return total;}
    public String findLongestWord(){String best="";for(String s:sentences)for(String word:words(s))if(word.length()>best.length())best=word;return best;}
    public void removeShortWords(int minLength){if(minLength<0)throw new IllegalArgumentException("Negative length");for(int i=0;i<sentences.size();i++){ArrayList<String> kept=new ArrayList<>();for(String word:words(sentences.get(i)))if(word.length()>=minLength)kept.add(word);sentences.set(i,String.join(" ",kept));}}
    public String toString(){return sentences.toString();}
}
