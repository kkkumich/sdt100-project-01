package part2_numbers;
import java.util.ArrayList;
public class NumberAnalyzer {
    private final ArrayList<Integer> numbers=new ArrayList<>();
    public void addNumber(int n){numbers.add(n);}
    private void requireValues(){if(numbers.isEmpty())throw new IllegalStateException("No numbers");}
    public double getAverage(){requireValues();long sum=0;for(int n:numbers)sum+=n;return (double)sum/numbers.size();}
    public int getMax(){requireValues();int best=numbers.get(0);for(int n:numbers)best=Math.max(best,n);return best;}
    public int getMin(){requireValues();int best=numbers.get(0);for(int n:numbers)best=Math.min(best,n);return best;}
    public void removeNegativeNumbers(){numbers.removeIf(n->n<0);}
    public String toString(){return numbers.toString();}
}
