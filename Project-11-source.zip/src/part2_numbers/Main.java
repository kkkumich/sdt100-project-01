package part2_numbers;
import java.util.Random;
public class Main {
    static void report(NumberAnalyzer n){System.out.println(n);System.out.println("Average="+n.getAverage()+", max="+n.getMax()+", min="+n.getMin());}
    public static void main(String[] args){NumberAnalyzer n=new NumberAnalyzer();Random r=new Random(150);for(int i=0;i<5;i++){n.addNumber(-1-r.nextInt(50));n.addNumber(r.nextInt(51));}report(n);n.removeNegativeNumbers();System.out.println("After removing negatives:");report(n);}
}
