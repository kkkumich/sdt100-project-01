# Project 12. Working with Files

Canvas: https://auk.instructure.com/courses/1274/assignments/33054

## Состав

- `part1_stats.TextFileStats`
- `part2_todo.TodoListApp`

## Запуск

Требуется JDK 21. В IntelliJ: открыть проект, выбрать JDK, отметить src как Sources Root. Каждая часть запускается своим main. Рабочая папка — корень этого проекта.

Из PowerShell:

```powershell
$sourceFiles = @(Get-ChildItem src -Recurse -Filter *.java | ForEach-Object FullName)
javac -encoding UTF-8 -d build @sourceFiles
java -cp build part1_stats.TextFileStats
java -cp build part2_todo.TodoListApp
```

## Что показать на защите

Для статистики укажи data/notes.txt. В TODO добавь задачу, сохрани, перезапусти и покажи загрузку. Покажи поведение при отсутствующем файле.

## Как объяснить

Текст читается в UTF-8 построчно через BufferedReader и try-with-resources. readLine убирает разделитель строки. TODO при запуске читает файл в память; добавление меняет только список, а сохранение выполняется по команде 3.

## Возможные вопросы

- **Что считается непустой строкой?** Строка, для которой isBlank возвращает false.
- **Включены ли переводы строк в символы?** Нет: считаются line.length(), включая пробелы. Это явно указанное допущение к неоднозначному условию.
- **Когда сохраняется TODO?** Только при выборе Save and exit; при ошибке сохранения программа остаётся в меню.

## Замечания

Число символов — UTF-16 кодовые единицы Java, не размер файла в байтах. todo.txt создаётся в текущей рабочей папке, поэтому в IntelliJ выбери папку project12 как Working directory.

Файл RUNS.txt содержит настоящие результаты локального запуска с демонстрационным вводом. Это журналы, а не скриншоты IntelliJ. Проверка выполнена 26 ноября 2026. Ошибочные учебные примеры находятся отдельно от src.
