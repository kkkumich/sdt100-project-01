package part2_todo;
import common.Input;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.io.IOException;
public class TodoListApp {
    public static List<String> load(Path path)throws IOException{return Files.exists(path)?new ArrayList<>(Files.readAllLines(path,StandardCharsets.UTF_8)):new ArrayList<>();}
    public static void save(Path path,List<String> tasks)throws IOException{Files.write(path,tasks,StandardCharsets.UTF_8);}
    public static void main(String[] args){
        Path path=Path.of("todo.txt");List<String> tasks;
        try{tasks=load(path);}catch(IOException e){System.out.println("Cannot load tasks; exiting to avoid overwriting an unreadable file: "+e.getMessage());return;}
        while(true){System.out.println("==== TODO MENU ====\n1 - Show all tasks\n2 - Add a new task\n3 - Save and exit");
            switch(Input.integer("Choose option: ",1,3)){
                case 1:if(tasks.isEmpty())System.out.println("No tasks yet.");else for(int i=0;i<tasks.size();i++)System.out.println((i+1)+". "+tasks.get(i));break;
                case 2:String task=Input.text("Enter new task description: ");if(task.isEmpty())System.out.println("Task cannot be empty.");else tasks.add(task);break;
                case 3:try{save(path,tasks);System.out.println("Saved to "+path.toAbsolutePath());return;}catch(IOException e){System.out.println("Save failed; tasks remain in memory: "+e.getMessage());}break;
            }
        }
    }
}
