package part1_stats;
import common.Input;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
public class TextFileStats {
    public static long[] analyze(Path path)throws IOException{
        long lines=0,nonEmpty=0,characters=0;
        try(BufferedReader reader=Files.newBufferedReader(path,StandardCharsets.UTF_8)){
            String line;while((line=reader.readLine())!=null){lines++;if(!line.isBlank())nonEmpty++;characters+=line.length();}
        }
        // Line separators are excluded: readLine removes them. Java length counts UTF-16 code units.
        return new long[]{lines,nonEmpty,characters};
    }
    public static void main(String[] args){
        try {long[] s=analyze(Path.of(Input.text("Enter file path: ")));System.out.println("Total lines: "+s[0]+"\nNon-empty lines: "+s[1]+"\nTotal characters: "+s[2]);}
        catch(IOException|InvalidPathException e){System.out.println("Cannot read file: "+e.getMessage());}
    }
}
