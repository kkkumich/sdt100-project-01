package app;

import books.Book;
import database.BookCollection;
import common.Input;
import java.io.IOException;
public class Main {
    static void addBook(BookCollection books){
        String title=Input.text("Book title: ");String author=Input.text("Author: ");
        int year=Input.integer("Publication year: ",1,9999);int pages=Input.integer("Pages: ",1,1000000);
        Book book=new Book(title,author,year,pages);book.notes=Input.text("Notes (optional): ");books.add(book);
    }
    static void removeBook(BookCollection books){
        if(books.size()==0){System.out.println("No books.");return;}books.printList();books.remove(Input.integer("Number to remove: ",1,books.size())-1);
    }
    static void editBook(BookCollection books){
        if(books.size()==0){System.out.println("No books.");return;}
        books.printList();Book book=books.get(Input.integer("Number to edit: ",1,books.size())-1);
        // Validate all new values in a temporary object before changing the selected book.
        Book updated=new Book(Input.text("New title: "),Input.text("New author: "),Input.integer("New year: ",1,9999),Input.integer("New pages: ",1,1000000));
        String notes=Input.text("New notes: ");book.setTitle(updated.getTitle());book.setAuthor(updated.getAuthor());book.setYear(updated.getYear());book.setPages(updated.getPages());book.notes=notes;
    }
    static void showOne(BookCollection books){if(books.size()==0)System.out.println("No books.");else books.printOne(Input.integer("Book number: ",1,books.size())-1);}
    static void menu(){System.out.println("Welcome to the book database!\n1 List | 2 Add | 3 Remove | 4 Sort by year\n5 Search author | 6 Search year | 7 Details\n8 Load books.tsv | 9 Save books.tsv | 10 Edit | 11 Show one | 0 Exit");}
    public static void main(String[] args){BookCollection books=new BookCollection();while(true){menu();try{
        switch(Input.integer("Choose: ",0,11)){
            case 0:System.out.println("Goodbye. Use option 9 to save before exiting.");return;
            case 1:books.printList();break;case 2:addBook(books);break;case 3:removeBook(books);break;
            case 4:books.sort();System.out.println("Sorted.");break;case 5:books.search(Input.text("Author contains: "));break;
            case 6:books.searchByYear(Input.integer("Year: ",1,9999));break;case 7:books.printAll();break;
            case 8:books.readFromFile();System.out.println("Loaded.");break;case 9:books.saveToFile();System.out.println("Saved.");break;
            case 10:editBook(books);break;case 11:showOne(books);break;
        }
    }catch(IOException|IllegalArgumentException e){System.out.println("Operation failed: "+e.getMessage());}}}
}
