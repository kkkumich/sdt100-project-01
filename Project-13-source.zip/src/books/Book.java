package books;
/** A book is one hobby artefact. Different instances have independent state. */
public class Book {
    public String notes=""; // Public member required by Project 13.
    private String title,author;
    private int year,pages;
    public Book(String title,String author,int year,int pages) { setTitle(title); setAuthor(author); setYear(year); setPages(pages); }
    public String getTitle() { return title; }
    public void setTitle(String value) { if(value==null || value.trim().isEmpty()) throw new IllegalArgumentException("Blank title"); title=value.trim(); }
    public String getAuthor() { return author; }
    public void setAuthor(String value) { if(value==null || value.trim().isEmpty()) throw new IllegalArgumentException("Blank author"); author=value.trim(); }
    public int getYear() { return year; }
    public void setYear(int value) { if(value<1 || value>9999) throw new IllegalArgumentException("Year must be 1-9999"); year=value; }
    public int getPages() { return pages; }
    public void setPages(int value) { if(value<1) throw new IllegalArgumentException("Pages must be positive"); pages=value; }
    public double readingHours() { return pages/30.0; }
    public String getDescription() { return title+"\nAuthor: "+author+"\nYear: "+year+"\nPages: "+pages+"\nEstimated reading hours (30 pages/hour): "+readingHours()+"\nNotes: "+notes; }
}
