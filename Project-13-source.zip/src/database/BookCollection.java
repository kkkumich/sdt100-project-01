package database;
import books.Book;
import java.util.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
public class BookCollection {
    public static final Path FILE=Path.of("books.tsv");
    private Book[] items=new Book[0];
    private int count=0;
    public int size(){return count;}
    public Book get(int i){if(i<0||i>=count)throw new IllegalArgumentException("Invalid index");return items[i];}
    public void add(Book item){if(item==null)throw new IllegalArgumentException("Null item");items=Arrays.copyOf(items,count+1);items[count++]=item;}
    public void remove(int i){get(i);Book[] replacement=new Book[count-1];System.arraycopy(items,0,replacement,0,i);System.arraycopy(items,i+1,replacement,i,count-i-1);items=replacement;count--;}
    public void printOne(int i){System.out.println((i+1)+". "+get(i).getDescription());}
    public void printAll(){for(int i=0;i<count;i++)printOne(i);if(count==0)System.out.println("No books.");}
    public void printList(){for(int i=0;i<count;i++)System.out.println((i+1)+". "+items[i].getTitle());if(count==0)System.out.println("No books.");}
    public void sort(){for(int end=count-1;end>0;end--){boolean changed=false;for(int j=0;j<end;j++)if(items[j].getYear()>items[j+1].getYear()){Book temp=items[j];items[j]=items[j+1];items[j+1]=temp;changed=true;}if(!changed)break;}}
    public void search(String phrase){boolean found=false;for(int i=0;i<count;i++)if(items[i].getAuthor().toLowerCase(Locale.ROOT).contains(phrase.toLowerCase(Locale.ROOT))){printOne(i);found=true;}if(!found)System.out.println("No matching authors.");}
    public void searchByYear(int year){boolean found=false;for(int i=0;i<count;i++)if(items[i].getYear()==year){printOne(i);found=true;}if(!found)System.out.println("No matching years.");}
    private static String encode(String s){return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));}
    private static String decode(String s){return new String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8);}
    public void saveToFile()throws IOException{saveToFile(FILE);}
    public void saveToFile(Path path)throws IOException{
        List<String> lines=new ArrayList<>();
        for(Book book:items)lines.add(encode(book.getTitle())+"\t"+encode(book.getAuthor())+"\t"+book.getYear()+"\t"+book.getPages()+"\t"+encode(book.notes));
        Files.write(path,lines,StandardCharsets.UTF_8);
    }
    public void readFromFile()throws IOException{readFromFile(FILE);}
    public void readFromFile(Path path)throws IOException{
        List<String> lines=Files.readAllLines(path,StandardCharsets.UTF_8);BookCollection loaded=new BookCollection();
        for(int i=0;i<lines.size();i++)try{
            String[] columns=lines.get(i).split("\t",-1);if(columns.length!=5)throw new IllegalArgumentException("Expected five fields");
            Book book=new Book(decode(columns[0]),decode(columns[1]),Integer.parseInt(columns[2]),Integer.parseInt(columns[3]));book.notes=decode(columns[4]);loaded.add(book);
        }catch(IllegalArgumentException e){throw new IOException("Invalid book record on line "+(i+1),e);}
        // Replace current data only after every record has been parsed successfully.
        items=loaded.items;count=loaded.count;
    }
}
